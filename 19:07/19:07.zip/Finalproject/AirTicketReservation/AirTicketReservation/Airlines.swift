//
//  Airlines.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Airlines  {
    
    var airlineId : String?
    var airlineDescription : String?
    var airlineType : String?
    var airlineCost : Int?
    
    
    
}
