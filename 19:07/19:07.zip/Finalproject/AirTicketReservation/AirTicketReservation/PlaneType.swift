//
//  PlaneType.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class planetype  {
    
    var planeTypeId : String?
    var planeTypeSeats : String?
    var seatMap : [[(String, Int)]] = []
    
    
    
}
