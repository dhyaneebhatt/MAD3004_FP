//
//  AirlinesEnquiry.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class AirlinesEnquiry  {
    
    var EnquiryId : Int?
    var EnquiryType : String?
    var EnquiryTitle : String?
    var EnquiryDescription : String?
    var EnquiryDate: Date?
   
    
    
    
    
}
