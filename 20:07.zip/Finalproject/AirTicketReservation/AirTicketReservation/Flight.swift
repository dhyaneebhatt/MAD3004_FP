//
//  Flight.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight  {
    
    var FlightId : String?
    var FlightFrom : String?
    var FlightTo : String?
    var FlightSchduleDate : Date?
    var FlightAirlineId : String?
    var FlightPilotId : String?
    
    
    
    
    
}
