//
//  Reservation.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation  {
    
    var ReservationId : Int?
    var ReservationDescription : String?
    var ReservationPassengerId : String?
    var ReservationFlightId : String?
    var ReservationDate: Date?
    var ReservationSeatNumber : String?
    var ReservationStatus : String?
    var ReservationMealType : String?
    var ReservationTotalcost : String?
    var ReservationPaymentType : String?
    
    
    
    
    
}
