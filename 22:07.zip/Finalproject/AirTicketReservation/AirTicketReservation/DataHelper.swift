//
//  DataHelper.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class  DataHelper
{
    var SeatMap = [Int : PlaneType]()
    //[:] is a dictonary
    init()
    {
        self.loadSeatMap()
    }

    func loadSeatMap()
    {
        SeatMap = [:]
        
      //  let A = PlaneType(rawValue: 1 )
      //  SeatMap[A.planetypeID!] = A
        
        
    }


}
