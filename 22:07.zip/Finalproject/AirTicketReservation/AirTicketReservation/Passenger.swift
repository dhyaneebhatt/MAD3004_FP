//
//  Passenger.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Passenger  {
    
    var PassengerId : String?
    var PassengerPassportNumber : String?
    var PassengerName : String?
    var PassengerEmail : String?
    var PassengerMobile : String?
    var PassengerAddress : String?
    var PassengerDob: String?
   
    
    
    
}
