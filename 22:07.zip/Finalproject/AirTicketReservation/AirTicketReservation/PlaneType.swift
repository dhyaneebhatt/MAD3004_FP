//
//  PlaneType.swift
//  AirTicketReservation
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class planetype : IDisplay
{
   
    
    
    var planeTypeId : String?
    var planeTypeName : PlaneType?
    var planeTypeSeats : String?
    var seatMap : [[(String, Int)]] = []
    
    func displayData() -> String
    {
        var returnData = ""
        returnData += "planeType ID: \(self.planeTypeId ?? "")\n"
        returnData += "planeType Name : \(self.planeTypeName ?? PlaneType.None)\n"
        returnData += "planeTypeSeats : \(self.planeTypeSeats ?? "" )\n"
        //returnData += "seatMap : \(self.seatMap ?? "["",0]")\n "
        return returnData
    }
    
}
